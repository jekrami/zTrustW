---
name: New blockchain
about: Request a new blockchain support
title: ''
labels: chain-integration
assignees: ''

---

<!--- Before submitting please check to see if this coin was already requested -->
<!--- Provide as many relevant details about the coin -->
## Description

<!-- Coin Name and official website e.g. [Bitcoin](https://bitcoin.org) -->
Name:
<!-- HD Derivation Scheme e.g. BIP44 / 0 -->
HD Derivation Scheme:
<!-- Symbol e.g. BTC -->
Symbol:
<!-- Documentation (Address / Transaction signing etc) and reference implementation links -->
Documentation:
<!-- Why we should support it? -->
Reason:

## Checklist

Finish check list [here](https://developer.trustwallet.com/wallet-core/newblockchain#blockchain-checklist).
