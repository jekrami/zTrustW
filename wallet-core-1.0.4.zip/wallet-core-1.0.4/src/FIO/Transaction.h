// Copyright © 2017-2020 Trust Wallet.
//
// This file is part of Trust. The full Trust copyright notice, including
// terms governing use, modification, and redistribution, is contained in the
// file LICENSE at the root of the source code distribution tree.

#pragma once

#include "Action.h"
#include "../Data.h"

#include <vector>

namespace TW::FIO {

/// A Transaction.  Some common fields, and one or more actions.
class Transaction {
public:
    int32_t expiration = 0;
    uint16_t refBlockNumber = 0;
    uint32_t refBlockPrefix = 0;
    std::vector<Action> actions;

    void serialize(Data& os) const;
};

} // namespace TW::FIO
