Documents had been moved to https://developer.trustwallet.com/wallet-core.
